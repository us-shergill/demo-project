import requests
from redis import Redis
from rq import Queue
import json

q = Queue(connection=Redis())


def persist_to_db(coin,response):
    pass


def get_coindata_from_coingecko(id):
    url = f"https://api.coingecko.com/api/v3/coins/{id}/tickers"
    response = requests.get(url)
    persist_to_db(id, json.loads(response.text))


def transform_coins(coins):
    print("success")
    for coin in coins:
        q.enqueue(get_coindata_from_coingecko, coin)
