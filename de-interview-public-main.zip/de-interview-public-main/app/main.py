from fastapi import FastAPI
from app.api import api
from pydantic import BaseModel
from typing import List


app = FastAPI()


class Coins(BaseModel):
    coins: List[str] = []


@app.get("/")
async def root():
    return {"message": "Hello World"}


@app.post("/enrichcoins", status_code=200)
def enrich_coins_and_persist(coins: Coins):
    api.transform_coins(coins.coins)
    return coins