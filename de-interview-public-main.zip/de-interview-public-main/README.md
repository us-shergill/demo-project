# Alaffia Data Engineering Challenge

Welcome to the Alaffia data engineering challenge! This challenge is meant to determine your proficiency in building ETL (extract, transform, load) pipelines.
You will be graded on the robustness your pipeline and the correctness of the output. Performance of the pipeline and queryability of the output will also be considered, but are not priorities.
Your code should contain instructions on how to run your pipeline.

## Goal
You are to create a pipeline that recieves `POST` requests every `400ms` containing tasks in the form of cryptocurrency coin `id`s.
These `id`s are to be transformed to include the `exchanges` that the coin is traded on, and stored to include the `id`, `exchanges`, and `task_run` (the request number) the `id` was first included in.

### Challenges
- The body of a task request may be in `csv` or `json` format, denoted by the `Content-Type` header `text/csv` or `application/json` respectively.
    - `csv` bodies will contains a single header `coins` with a variable number of `id`s rows
    - `json` bodies will contain a single key `coins` with an array of `id`s
- Any task body may contain a coin `id` that is incorrect, which is to be ignored and not stored in the output (`coinGecko` will return a "Could not find coin with the given id" error)
- Any `id` may appear in multiple tasks (requests), and duplicates are to be ignored and not stored in the output
- The `coinGecko` api **will throttle** requests from your IP for a short period of time if hit frequently enough. Your implementation **must handle throttling** and output all valid, requested task coin `id`s
- Your pipeline's endpoint must respond with a `200` status code within `400ms`

### Input
The `coin-spewer` cli included in the repo is to be run for your input. It takes the following cli arguments.
- `--endpoint/-e`: endpoint to `POST` to (required)
- `--requests/-r`: number of requests to send (default 1000)
- `--permutations/-p`: number of coins per task (default 4)
- `--delay/-d`: number of milliseconds between requests (default 400)

You may run the rust code directly from source with [`cargo run -- -e {your-endpoint}`](https://www.rust-lang.org/tools/install), or download and run one of the released binaries.

### Transformation
You may use the [coinGecko api](https://www.coingecko.com/api/documentations/v3) to query for a coin by `id` at `https://api.coingecko.com/api/v3/coins/{id}/tickers`.
The exchanges that a given coin is traded on are the `tickers[].market.identifier`s.

### Your Work
You are free to use any languages and frameworks. Possible runnables might include:
- Docker Compose file pointing to local and/or publicly available `Dockerfile`s
- Airflow instance started locally
- Kubeflow running on MiniKube (with instructions on how to run locally)
- A `Makefile` file that calls other scripts

Your output may be in any format that can later be queried or read into a dataframe to verify correctness.
Outputs might include:
- Postgres or MySQL instance with setup instructions (can be as simple as running a docker container)
- SQLite, Parquet, CSV, or JSON file(s)

Please include a `README.md` to explain any pipeline setup instructions.

### Output
Your output must use the following schema, barring the idiosyncrasies of your chosen output format.
```sql
-- id of the coin from the input
id text,
-- array of exchanges the coin is traded on
exchanges text[],
-- task number this coin was first included in
task_run int
```
##### Example JSON
```json
[
  {
    "id": "dentacoin",
    "exchanges": [
      "hitbtc",
      "hotbit",
      "digifinex",
      "bitmart",
      "uniswap_v2",
      "cointiger",
      "graviex",
      "mercatox",
      "one_inch_liquidity_protocol",
      "uniswap",
      "buyucoin",
      "bitcratic"
    ],
    "taskRun": 1
  },
  {
    "id": "pascalcoin",
    "exchanges": ["tokok", "finexbox", "bilaxy", "vitex", "qtrade", "vitex"],
    "taskRun": 2
  }
]
```

### Questions
Please ask any questions you may have via email during the challenge.

### Other Notes
Although we use the term pipeline, your code may consist of a single application.
Best of luck and happy coding!


# Alaffia Data Engineering Answer
I have created a Python based FAST API application with POST endpoint to tranformt the coin data
and save it to the database . In order for the application to be responsive I will be submitting the
coin request to the backend redis task queue to handle the submission of requests to the coingekko
and persisting to the database as a backend process . This helps in the API POST request to highly
responsive and return in less than 400 ms . The throttle logic can be implemented while submitting the
request to coingekko by adding an await time that would not result in coingekko throttling the requests
# Pre-requisites
Installing poetry and redis server is a pre req for this project . Due to lack of time I was not able
to thoroughly test it out . However most of the features requested can be implement without much effort
once a good design is in place